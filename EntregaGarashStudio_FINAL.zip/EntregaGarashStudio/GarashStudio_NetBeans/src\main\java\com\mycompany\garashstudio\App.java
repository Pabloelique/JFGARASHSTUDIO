package com.mycompany.garashstudio;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class App extends Application {

    @Override
    public void start(Stage escenario) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("LoginRegistro.fxml"));
        Scene escena = new Scene(fxmlLoader.load());
        escenario.setResizable(false);
        escenario.setTitle("Garash Studio - Acceso");
        escenario.setScene(escena);
        escenario.show();
    }

    public static void main(String[] args) {
        GestorFicheros.inicializar();
        launch();
    }
}
