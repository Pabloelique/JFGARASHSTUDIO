package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Empleado;
import com.mycompany.garashstudio.clases.Peluquero;
import com.mycompany.garashstudio.clases.Recepcionista;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GestionEmpleadosController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private TextField campoDni;
    @FXML private TextField campoNombre;
    @FXML private TextField campoTelefono;
    @FXML private TextField campoSalario;
    @FXML private TextField campoFechaContratacion;
    @FXML private ComboBox<String> comboTipo;
    @FXML private TextField campoEspecialidadTurno;
    @FXML private CheckBox checkActivo;
    @FXML private TextField campoRegistro;
    @FXML private TextField campoMensaje;
    @FXML private Button btnSalir;
    @FXML private ListView<String> listaRegistros;

    private static String usuario;
    private ArrayList<Empleado> empleados = new ArrayList<>();
    private int contReg = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        comboTipo.setItems(FXCollections.observableArrayList("Peluquero", "Recepcionista"));
        comboTipo.setValue("Peluquero");
        cargarDesdeFichero();
        if (!empleados.isEmpty()) actualizarCampos();
        listaRegistros.setOnMouseClicked(e -> {
            int idx = listaRegistros.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && idx < empleados.size()) { contReg = idx; actualizarCampos(); }
        });
    }

    private void cargarDesdeFichero() {
        empleados = GestorFicheros.cargarEmpleados();
        contReg = 0;
        actualizarLista();
    }

    private void actualizarLista() {
        javafx.collections.ObservableList<String> items = javafx.collections.FXCollections.observableArrayList();
        for (Empleado e : empleados)
            items.add(e.getDni() + " | " + e.getNombre() + " [" + e.getTipo() + "]");
        listaRegistros.setItems(items);
        if (contReg < empleados.size()) listaRegistros.getSelectionModel().select(contReg);
    }

    private void actualizarCampos() {
        Empleado e = empleados.get(contReg);
        campoDni.setText(String.valueOf(e.getDni()));
        campoNombre.setText(e.getNombre());
        campoTelefono.setText(e.getTelefono());
        campoSalario.setText(String.valueOf(e.getSalarioBase()));
        campoFechaContratacion.setText(e.getFechaContratacion());
        checkActivo.setSelected(e.isActivo());
        comboTipo.setValue(e.getTipo());
        if (e instanceof Peluquero)
            campoEspecialidadTurno.setText(((Peluquero) e).getEspecialidad());
        else if (e instanceof Recepcionista)
            campoEspecialidadTurno.setText(((Recepcionista) e).getTurno());
        campoRegistro.setText(contReg + "/" + (empleados.size() - 1));
    }

    private int buscarEmpleado(int dni) {
        for (int i = 0; i < empleados.size(); i++)
            if (empleados.get(i).getDni() == dni) return i;
        return -1;
    }

    @FXML
    private void darDeAlta(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            if (buscarEmpleado(dni) != -1) { campoMensaje.setText("Ya existe un empleado con ese DNI"); return; }
            if (campoNombre.getText().isEmpty()) { campoMensaje.setText("El nombre es obligatorio"); return; }
            double salario = campoSalario.getText().isEmpty() ? 1000.0 : Double.parseDouble(campoSalario.getText());
            String fecha = campoFechaContratacion.getText().isEmpty() ? "2024-01-01" : campoFechaContratacion.getText();
            Empleado nuevo;
            if ("Peluquero".equals(comboTipo.getValue()))
                nuevo = new Peluquero(dni, campoNombre.getText(), campoTelefono.getText(), salario, fecha, campoEspecialidadTurno.getText());
            else
                nuevo = new Recepcionista(dni, campoNombre.getText(), campoTelefono.getText(), salario, fecha, campoEspecialidadTurno.getText());
            nuevo.setActivo(checkActivo.isSelected());
            empleados.add(nuevo);
            GestorFicheros.guardarEmpleados(empleados);
            cargarDesdeFichero();
            contReg = empleados.size() - 1;
            actualizarCampos();
            campoMensaje.setText("Empleado dado de alta: DNI " + dni);
        } catch (NumberFormatException e) {
            campoMensaje.setText("DNI y salario deben ser numericos");
        }
    }

    @FXML
    private void darDeBaja(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI del empleado"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            int idx = buscarEmpleado(dni);
            if (idx == -1) { campoMensaje.setText("No existe empleado con DNI: " + dni); return; }
            empleados.remove(idx);
            GestorFicheros.guardarEmpleados(empleados);
            campoMensaje.setText("Empleado DNI " + dni + " eliminado");
            cargarDesdeFichero();
            if (!empleados.isEmpty()) actualizarCampos(); else limpiarCampos(event);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El DNI debe ser un numero entero");
        }
    }

    @FXML
    private void modificarDatos(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI del empleado"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            int idx = buscarEmpleado(dni);
            if (idx == -1) { campoMensaje.setText("No existe empleado con DNI: " + dni); return; }
            double salario = campoSalario.getText().isEmpty() ? 1000.0 : Double.parseDouble(campoSalario.getText());
            Empleado e = empleados.get(idx);
            String tipoNuevo = comboTipo.getValue();
            if (!e.getTipo().equals(tipoNuevo)) {
                Empleado reemplazado;
                if ("Peluquero".equals(tipoNuevo))
                    reemplazado = new Peluquero(dni, campoNombre.getText(), campoTelefono.getText(), salario, campoFechaContratacion.getText(), campoEspecialidadTurno.getText());
                else
                    reemplazado = new Recepcionista(dni, campoNombre.getText(), campoTelefono.getText(), salario, campoFechaContratacion.getText(), campoEspecialidadTurno.getText());
                reemplazado.setActivo(checkActivo.isSelected());
                empleados.set(idx, reemplazado);
            } else {
                e.setNombre(campoNombre.getText());
                e.setTelefono(campoTelefono.getText());
                e.setSalarioBase(salario);
                e.setFechaContratacion(campoFechaContratacion.getText());
                e.setActivo(checkActivo.isSelected());
                if (e instanceof Peluquero) ((Peluquero) e).setEspecialidad(campoEspecialidadTurno.getText());
                else if (e instanceof Recepcionista) ((Recepcionista) e).setTurno(campoEspecialidadTurno.getText());
            }
            GestorFicheros.guardarEmpleados(empleados);
            cargarDesdeFichero();
            contReg = buscarEmpleado(dni);
            actualizarCampos();
            campoMensaje.setText("Empleado DNI " + dni + " modificado");
        } catch (NumberFormatException e) {
            campoMensaje.setText("DNI y salario deben ser numericos");
        }
    }

    @FXML private void irAprimero(ActionEvent event)   { if (!empleados.isEmpty()) { contReg = 0; actualizarCampos(); } }
    @FXML private void irAanterior(ActionEvent event)  { if (!empleados.isEmpty()) { contReg = (contReg == 0) ? empleados.size()-1 : contReg-1; actualizarCampos(); } }
    @FXML private void irAsiguiente(ActionEvent event) { if (!empleados.isEmpty()) { contReg = (contReg < empleados.size()-1) ? contReg+1 : 0; actualizarCampos(); } }
    @FXML private void irAultimo(ActionEvent event)    { if (!empleados.isEmpty()) { contReg = empleados.size()-1; actualizarCampos(); } }

    @FXML
    private void limpiarCampos(ActionEvent event) {
        campoDni.setText(""); campoNombre.setText(""); campoTelefono.setText("");
        campoSalario.setText(""); campoFechaContratacion.setText(""); campoEspecialidadTurno.setText("");
        checkActivo.setSelected(true); comboTipo.setValue("Peluquero");
        campoRegistro.setText(""); campoMensaje.setText("");
    }

    @FXML
    private void salir(ActionEvent event) { ((Stage) btnSalir.getScene().getWindow()).close(); }

    public static void datosEntrada(String us) { usuario = us; }
}
