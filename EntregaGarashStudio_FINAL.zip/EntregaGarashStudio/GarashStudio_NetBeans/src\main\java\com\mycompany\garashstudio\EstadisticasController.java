package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class EstadisticasController implements Initializable {

    private static final int UMBRAL_FIDELIDAD = 5;

    @FXML private PieChart pieEstado;
    @FXML private BarChart<String, Number> barPeluquero;
    @FXML private Label labelTotalFidelidad;
    @FXML private Label labelUmbral;
    @FXML private ListView<String> listaFidelidad;
    @FXML private Button btnCerrar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarPieCitasEstado();
        cargarBarPeluquero();
        cargarTarjetaFidelidad();
    }

    // ── Grafico circular: citas por estado ────────────────────────────────────
    private void cargarPieCitasEstado() {
        ArrayList<Cita> citas = GestorFicheros.cargarCitas();
        int pend = 0, conf = 0, canc = 0, fin = 0;
        for (Cita c : citas) {
            switch (c.getEstado()) {
                case "Pendiente":  pend++; break;
                case "Confirmada": conf++; break;
                case "Cancelada":  canc++; break;
                case "Finalizada": fin++;  break;
            }
        }
        if (citas.isEmpty()) { pieEstado.setTitle("Sin citas registradas"); return; }

        ObservableList<PieChart.Data> datos = FXCollections.observableArrayList();
        if (pend > 0) datos.add(new PieChart.Data("Pendiente (" + pend + ")", pend));
        if (conf > 0) datos.add(new PieChart.Data("Confirmada (" + conf + ")", conf));
        if (fin  > 0) datos.add(new PieChart.Data("Finalizada (" + fin + ")", fin));
        if (canc > 0) datos.add(new PieChart.Data("Cancelada (" + canc + ")", canc));
        pieEstado.setData(datos);
        pieEstado.setTitle("Total: " + citas.size() + " citas");
    }

    // ── Grafico de barras: citas por peluquero ────────────────────────────────
    private void cargarBarPeluquero() {
        ArrayList<Cita> citas     = GestorFicheros.cargarCitas();
        ArrayList<Empleado> emps  = GestorFicheros.cargarEmpleados();

        XYChart.Series<String, Number> sTotal = new XYChart.Series<>(); sTotal.setName("Total");
        XYChart.Series<String, Number> sFin   = new XYChart.Series<>(); sFin.setName("Finalizadas");
        XYChart.Series<String, Number> sCan   = new XYChart.Series<>(); sCan.setName("Canceladas");

        boolean hayDatos = false;
        for (Empleado emp : emps) {
            if (!(emp instanceof Peluquero)) continue;
            int total = 0, fin = 0, can = 0;
            for (Cita c : citas) {
                if (c.getPeluqueroDni() == emp.getDni()) {
                    total++;
                    if ("Finalizada".equals(c.getEstado())) fin++;
                    if ("Cancelada".equals(c.getEstado()))  can++;
                }
            }
            String nombre = emp.getNombre();
            sTotal.getData().add(new XYChart.Data<>(nombre, total));
            sFin.getData().add(new XYChart.Data<>(nombre, fin));
            sCan.getData().add(new XYChart.Data<>(nombre, can));
            if (total > 0) hayDatos = true;
        }
        barPeluquero.getData().addAll(sTotal, sFin, sCan);
        if (!hayDatos) barPeluquero.setTitle("Sin citas registradas por peluquero");
    }

    // ── Tarjeta de fidelidad ──────────────────────────────────────────────────
    private void cargarTarjetaFidelidad() {
        ArrayList<Cita> citas        = GestorFicheros.cargarCitas();
        ArrayList<Cliente> clientes  = GestorFicheros.cargarClientes();

        labelUmbral.setText("Se obtiene tras completar " + UMBRAL_FIDELIDAD + " citas finalizadas  |  Beneficio: 10% descuento");

        ObservableList<String> items = FXCollections.observableArrayList();
        int conTarjeta = 0;

        // Cabecera de la lista
        items.add(String.format("  %-12s  %-22s  %9s  %s",
            "DNI", "Nombre", "Finalizadas", "Tarjeta desde"));
        items.add("  " + "-".repeat(62));

        for (Cliente cl : clientes) {
            ArrayList<String> fechasFinalizadas = new ArrayList<>();
            for (Cita c : citas) {
                if (c.getClienteDni() == cl.getDni() && "Finalizada".equals(c.getEstado()))
                    fechasFinalizadas.add(c.getFechaHora());
            }
            Collections.sort(fechasFinalizadas);

            if (fechasFinalizadas.size() >= UMBRAL_FIDELIDAD) {
                conTarjeta++;
                String fechaObt = fechasFinalizadas.get(UMBRAL_FIDELIDAD - 1);
                if (fechaObt.length() >= 10) fechaObt = fechaObt.substring(0, 10);
                String nombreCompleto = cl.getNombre() + " " + cl.getApellidos();
                items.add(String.format("  %-12d  %-22s  %9d  %s",
                    cl.getDni(), nombreCompleto, fechasFinalizadas.size(), fechaObt));
            }
        }

        if (conTarjeta == 0) {
            items.add("  Ningun cliente ha alcanzado el umbral de "
                + UMBRAL_FIDELIDAD + " citas finalizadas aun.");
        }

        labelTotalFidelidad.setText("Clientes con tarjeta de fidelidad: " + conTarjeta
            + " de " + clientes.size() + " registrados");
        listaFidelidad.setItems(items);
    }

    @FXML
    private void cerrar(ActionEvent event) {
        ((Stage) btnCerrar.getScene().getWindow()).close();
    }
}
