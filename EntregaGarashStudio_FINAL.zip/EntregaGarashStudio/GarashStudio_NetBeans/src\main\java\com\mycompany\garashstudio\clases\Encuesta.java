package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Encuesta implements Serializable {

    private int id;
    private int citaId;
    private String fecha;
    private int puntuacion;
    private String comentario;

    public Encuesta(int id, int citaId, String fecha, int puntuacion, String comentario) {
        this.id = id;
        this.citaId = citaId;
        this.fecha = fecha;
        this.puntuacion = puntuacion;
        this.comentario = comentario;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCitaId() { return citaId; }
    public void setCitaId(int citaId) { this.citaId = citaId; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public int getPuntuacion() { return puntuacion; }
    public void setPuntuacion(int puntuacion) { this.puntuacion = puntuacion; }

    public String getComentario() { return comentario; }
    public void setComentario(String comentario) { this.comentario = comentario; }
}
