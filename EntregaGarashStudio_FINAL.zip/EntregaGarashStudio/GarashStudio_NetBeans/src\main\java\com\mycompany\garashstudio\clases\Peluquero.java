package com.mycompany.garashstudio.clases;

public class Peluquero extends Empleado {

    private String especialidad;
    private int numServiciosRealizados;

    public Peluquero(int dni, String nombre, String telefono,
                     double salarioBase, String fechaContratacion, String especialidad) {
        super(dni, nombre, telefono, salarioBase, fechaContratacion);
        this.especialidad = especialidad;
        this.numServiciosRealizados = 0;
    }

    @Override
    public double calcularNomina() {
        return getSalarioBase() + (numServiciosRealizados * 5.0);
    }

    @Override
    public String getTipo() { return "Peluquero"; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public int getNumServiciosRealizados() { return numServiciosRealizados; }
    public void setNumServiciosRealizados(int n) { this.numServiciosRealizados = n; }

    public void incrementarServicios() { this.numServiciosRealizados++; }
}
