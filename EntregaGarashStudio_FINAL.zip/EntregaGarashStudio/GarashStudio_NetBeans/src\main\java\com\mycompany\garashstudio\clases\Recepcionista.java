package com.mycompany.garashstudio.clases;

public class Recepcionista extends Empleado {

    private String turno;

    public Recepcionista(int dni, String nombre, String telefono,
                         double salarioBase, String fechaContratacion, String turno) {
        super(dni, nombre, telefono, salarioBase, fechaContratacion);
        this.turno = turno;
    }

    @Override
    public double calcularNomina() {
        return getSalarioBase();
    }

    @Override
    public String getTipo() { return "Recepcionista"; }

    public String getTurno() { return turno; }
    public void setTurno(String turno) { this.turno = turno; }
}
