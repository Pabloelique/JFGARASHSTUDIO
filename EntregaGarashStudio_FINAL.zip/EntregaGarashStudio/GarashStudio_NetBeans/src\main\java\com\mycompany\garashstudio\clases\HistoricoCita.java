package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class HistoricoCita implements Serializable {

    private int id;
    private String clienteNombre;
    private String peluqueroNombre;
    private String fecha;
    private double total;

    public HistoricoCita(int id, String clienteNombre, String peluqueroNombre,
                         String fecha, double total) {
        this.id = id;
        this.clienteNombre = clienteNombre;
        this.peluqueroNombre = peluqueroNombre;
        this.fecha = fecha;
        this.total = total;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getClienteNombre() { return clienteNombre; }
    public void setClienteNombre(String clienteNombre) { this.clienteNombre = clienteNombre; }

    public String getPeluqueroNombre() { return peluqueroNombre; }
    public void setPeluqueroNombre(String peluqueroNombre) { this.peluqueroNombre = peluqueroNombre; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
}
