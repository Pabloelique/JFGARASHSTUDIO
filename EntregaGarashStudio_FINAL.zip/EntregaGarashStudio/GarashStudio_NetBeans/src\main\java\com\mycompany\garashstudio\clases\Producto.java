package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Producto implements Serializable {

    private int id;
    private String nombre;
    private double precioCompra;
    private double precioVenta;
    private int stockActual;
    private int stockMinimo;
    private String proveedor;

    public Producto(int id, String nombre, double precioCompra, double precioVenta,
                    int stockActual, int stockMinimo, String proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.stockActual = stockActual;
        this.stockMinimo = stockMinimo;
        this.proveedor = proveedor;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecioCompra() { return precioCompra; }
    public void setPrecioCompra(double precioCompra) { this.precioCompra = precioCompra; }

    public double getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(double precioVenta) { this.precioVenta = precioVenta; }

    public int getStockActual() { return stockActual; }
    public void setStockActual(int stockActual) { this.stockActual = stockActual; }

    public int getStockMinimo() { return stockMinimo; }
    public void setStockMinimo(int stockMinimo) { this.stockMinimo = stockMinimo; }

    public String getProveedor() { return proveedor; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }

    public boolean esStockBajo() { return stockActual <= stockMinimo; }

    public void aumentarStock(int cantidad) { this.stockActual += cantidad; }

    public void reducirStock(int cantidad) {
        if (cantidad <= stockActual) this.stockActual -= cantidad;
    }

    @Override
    public String toString() {
        return id + " - " + nombre;
    }
}
