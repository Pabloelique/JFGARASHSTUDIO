package com.mycompany.garashstudio;

// Sustituido por GestorFicheros.java
public class ConexionBD {
    public static void inicializarBD() { GestorFicheros.inicializar(); }
}
