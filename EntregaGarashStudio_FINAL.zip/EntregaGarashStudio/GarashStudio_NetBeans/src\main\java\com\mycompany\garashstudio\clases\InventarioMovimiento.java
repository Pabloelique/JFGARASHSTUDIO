package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class InventarioMovimiento implements Serializable {

    private int id;
    private int productoId;
    private String fecha;
    private String tipo;
    private int cantidad;
    private String motivo;

    public InventarioMovimiento(int id, int productoId, String fecha,
                                String tipo, int cantidad, String motivo) {
        this.id = id;
        this.productoId = productoId;
        this.fecha = fecha;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.motivo = motivo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getProductoId() { return productoId; }
    public void setProductoId(int productoId) { this.productoId = productoId; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
}
