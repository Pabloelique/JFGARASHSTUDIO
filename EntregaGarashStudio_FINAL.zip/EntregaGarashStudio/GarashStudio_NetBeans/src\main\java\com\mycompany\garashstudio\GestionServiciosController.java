package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Servicio;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GestionServiciosController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private TextField campoId;
    @FXML private TextField campoNombre;
    @FXML private TextField campoPrecio;
    @FXML private TextField campoDuracion;
    @FXML private TextField campoCategoria;
    @FXML private TextField campoDescripcion;
    @FXML private TextField campoRegistro;
    @FXML private TextField campoMensaje;
    @FXML private Button btnSalir;
    @FXML private ListView<String> listaRegistros;

    private static String usuario;
    private ArrayList<Servicio> servicios = new ArrayList<>();
    private int contReg = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        cargarDesdeFichero();
        if (!servicios.isEmpty()) actualizarCampos();
        listaRegistros.setOnMouseClicked(e -> {
            int idx = listaRegistros.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && idx < servicios.size()) { contReg = idx; actualizarCampos(); }
        });
    }

    private void cargarDesdeFichero() {
        servicios = GestorFicheros.cargarServicios();
        contReg = 0;
        actualizarLista();
    }

    private void actualizarLista() {
        javafx.collections.ObservableList<String> items = javafx.collections.FXCollections.observableArrayList();
        for (Servicio s : servicios)
            items.add("ID:" + s.getId() + " | " + s.getNombre() + " | " + s.getPrecio() + "EUR");
        listaRegistros.setItems(items);
        if (contReg < servicios.size()) listaRegistros.getSelectionModel().select(contReg);
    }

    private void actualizarCampos() {
        Servicio s = servicios.get(contReg);
        campoId.setText(String.valueOf(s.getId()));
        campoNombre.setText(s.getNombre());
        campoPrecio.setText(String.valueOf(s.getPrecio()));
        campoDuracion.setText(String.valueOf(s.getDuracionMin()));
        campoCategoria.setText(s.getCategoria());
        campoDescripcion.setText(s.getDescripcion());
        campoRegistro.setText(contReg + "/" + (servicios.size() - 1));
    }

    private int buscarServicio(int id) {
        for (int i = 0; i < servicios.size(); i++)
            if (servicios.get(i).getId() == id) return i;
        return -1;
    }

    @FXML
    private void darDeAlta(ActionEvent event) {
        if (campoNombre.getText().isEmpty()) { campoMensaje.setText("El nombre del servicio es obligatorio"); return; }
        try {
            double precio   = campoPrecio.getText().isEmpty()   ? 0.0 : Double.parseDouble(campoPrecio.getText());
            int    duracion = campoDuracion.getText().isEmpty() ? 30  : Integer.parseInt(campoDuracion.getText());
            int nuevoId = GestorFicheros.nextIdServicio();
            servicios.add(new Servicio(nuevoId, campoNombre.getText(), precio, duracion, campoDescripcion.getText(), campoCategoria.getText()));
            GestorFicheros.guardarServicios(servicios);
            cargarDesdeFichero();
            contReg = servicios.size() - 1;
            actualizarCampos();
            campoMensaje.setText("Servicio dado de alta: ID " + nuevoId);
        } catch (NumberFormatException e) {
            campoMensaje.setText("Precio y duracion deben ser numericos");
        }
    }

    @FXML
    private void darDeBaja(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID del servicio"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarServicio(id);
            if (idx == -1) { campoMensaje.setText("No existe servicio con ID: " + id); return; }
            servicios.remove(idx);
            GestorFicheros.guardarServicios(servicios);
            campoMensaje.setText("Servicio ID " + id + " eliminado");
            cargarDesdeFichero();
            if (!servicios.isEmpty()) actualizarCampos(); else limpiarCampos(event);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El ID debe ser un numero entero");
        }
    }

    @FXML
    private void modificarDatos(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID del servicio"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarServicio(id);
            if (idx == -1) { campoMensaje.setText("No existe servicio con ID: " + id); return; }
            Servicio s = servicios.get(idx);
            s.setNombre(campoNombre.getText());
            s.setPrecio(campoPrecio.getText().isEmpty()     ? 0.0 : Double.parseDouble(campoPrecio.getText()));
            s.setDuracionMin(campoDuracion.getText().isEmpty() ? 30 : Integer.parseInt(campoDuracion.getText()));
            s.setDescripcion(campoDescripcion.getText());
            s.setCategoria(campoCategoria.getText());
            GestorFicheros.guardarServicios(servicios);
            cargarDesdeFichero();
            contReg = buscarServicio(id);
            actualizarCampos();
            campoMensaje.setText("Servicio ID " + id + " modificado");
        } catch (NumberFormatException e) {
            campoMensaje.setText("Precio y duracion deben ser numericos");
        }
    }

    @FXML private void irAprimero(ActionEvent event)   { if (!servicios.isEmpty()) { contReg = 0; actualizarCampos(); } }
    @FXML private void irAanterior(ActionEvent event)  { if (!servicios.isEmpty()) { contReg = (contReg == 0) ? servicios.size()-1 : contReg-1; actualizarCampos(); } }
    @FXML private void irAsiguiente(ActionEvent event) { if (!servicios.isEmpty()) { contReg = (contReg < servicios.size()-1) ? contReg+1 : 0; actualizarCampos(); } }
    @FXML private void irAultimo(ActionEvent event)    { if (!servicios.isEmpty()) { contReg = servicios.size()-1; actualizarCampos(); } }

    @FXML
    private void limpiarCampos(ActionEvent event) {
        campoId.setText(""); campoNombre.setText(""); campoPrecio.setText("");
        campoDuracion.setText(""); campoCategoria.setText(""); campoDescripcion.setText("");
        campoRegistro.setText(""); campoMensaje.setText("");
    }

    @FXML
    private void salir(ActionEvent event) { ((Stage) btnSalir.getScene().getWindow()).close(); }

    public static void datosEntrada(String us) { usuario = us; }
}
