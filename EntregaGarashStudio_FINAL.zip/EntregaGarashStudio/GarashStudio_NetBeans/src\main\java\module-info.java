module com.mycompany.garashstudio {
    requires javafx.controls;
    requires javafx.fxml;
    requires MiLibreria;
    requires java.base;
    requires java.net.http;

    opens com.mycompany.garashstudio to javafx.fxml;
    exports com.mycompany.garashstudio;
}
