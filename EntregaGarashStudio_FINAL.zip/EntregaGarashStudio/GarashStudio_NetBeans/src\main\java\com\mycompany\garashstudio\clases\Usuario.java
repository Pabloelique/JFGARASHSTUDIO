package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Usuario implements Serializable {

    private String nombre;
    private String apellidos;
    private String telefono;
    private String email;
    private String password;
    private String tipo;
    private String fechaRegistro;
    private boolean activo;

    public Usuario(String nombre, String apellidos, String telefono, String email,
                   String password, String tipo, String fechaRegistro, boolean activo) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.email = email;
        this.password = password;
        this.tipo = tipo;
        this.fechaRegistro = fechaRegistro;
        this.activo = activo;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(String f) { this.fechaRegistro = f; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    @Override
    public String toString() { return nombre + " [" + tipo + "]"; }
}
