package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class RecordatorioCita implements Serializable {

    private int id;
    private int citaId;
    private String fechaEnvio;
    private String canal;
    private boolean enviado;

    public RecordatorioCita(int id, int citaId, String fechaEnvio, String canal) {
        this.id = id;
        this.citaId = citaId;
        this.fechaEnvio = fechaEnvio;
        this.canal = canal;
        this.enviado = false;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCitaId() { return citaId; }
    public void setCitaId(int citaId) { this.citaId = citaId; }

    public String getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(String fechaEnvio) { this.fechaEnvio = fechaEnvio; }

    public String getCanal() { return canal; }
    public void setCanal(String canal) { this.canal = canal; }

    public boolean isEnviado() { return enviado; }

    public void marcarComoEnviado() { this.enviado = true; }
}
