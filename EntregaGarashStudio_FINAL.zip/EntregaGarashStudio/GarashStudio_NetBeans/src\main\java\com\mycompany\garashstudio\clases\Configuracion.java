package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Configuracion implements Serializable {

    private double iva;
    private String horarioApertura;
    private String horarioCierre;
    private int stockMinimoGlobal;

    public Configuracion(double iva, String horarioApertura,
                         String horarioCierre, int stockMinimoGlobal) {
        this.iva = iva;
        this.horarioApertura = horarioApertura;
        this.horarioCierre = horarioCierre;
        this.stockMinimoGlobal = stockMinimoGlobal;
    }

    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }

    public String getHorarioApertura() { return horarioApertura; }
    public void setHorarioApertura(String horarioApertura) { this.horarioApertura = horarioApertura; }

    public String getHorarioCierre() { return horarioCierre; }
    public void setHorarioCierre(String horarioCierre) { this.horarioCierre = horarioCierre; }

    public int getStockMinimoGlobal() { return stockMinimoGlobal; }
    public void setStockMinimoGlobal(int stockMinimoGlobal) { this.stockMinimoGlobal = stockMinimoGlobal; }

    public void actualizarIVA(double nuevoIva) { this.iva = nuevoIva; }
}
