package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class TarjetaFidelidad implements Serializable {

    private int id;
    private int clienteDni;
    private int puntos;
    private String fechaAlta;
    private String nivel;

    public TarjetaFidelidad(int id, int clienteDni, String fechaAlta) {
        this.id = id;
        this.clienteDni = clienteDni;
        this.puntos = 0;
        this.fechaAlta = fechaAlta;
        this.nivel = "Bronce";
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getClienteDni() { return clienteDni; }
    public void setClienteDni(int clienteDni) { this.clienteDni = clienteDni; }

    public int getPuntos() { return puntos; }

    public String getFechaAlta() { return fechaAlta; }
    public void setFechaAlta(String fechaAlta) { this.fechaAlta = fechaAlta; }

    public String getNivel() { return nivel; }

    public void agregarPuntos(int cantidad) {
        this.puntos += cantidad;
        actualizarNivel();
    }

    public void canjearPuntos(int cantidad) {
        if (cantidad <= puntos) this.puntos -= cantidad;
    }

    private void actualizarNivel() {
        if (puntos >= 500) nivel = "Oro";
        else if (puntos >= 200) nivel = "Plata";
        else nivel = "Bronce";
    }
}
