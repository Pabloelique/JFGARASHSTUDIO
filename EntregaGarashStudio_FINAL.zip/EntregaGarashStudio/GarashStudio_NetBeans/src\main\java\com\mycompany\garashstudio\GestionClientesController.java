package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Cliente;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GestionClientesController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private TextField campoDni;
    @FXML private TextField campoNombre;
    @FXML private TextField campoApellidos;
    @FXML private TextField campoTelefono;
    @FXML private TextField campoEmail;
    @FXML private TextField campoFechaRegistro;
    @FXML private CheckBox checkActivo;
    @FXML private TextField campoRegistro;
    @FXML private TextField campoMensaje;
    @FXML private Button btnSalir;
    @FXML private ListView<String> listaRegistros;

    private static String usuario;
    private ArrayList<Cliente> clientes = new ArrayList<>();
    private int contReg = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        cargarDesdeFichero();
        if (!clientes.isEmpty()) actualizarCampos();
        listaRegistros.setOnMouseClicked(e -> {
            int idx = listaRegistros.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && idx < clientes.size()) { contReg = idx; actualizarCampos(); }
        });
    }

    private void cargarDesdeFichero() {
        clientes = GestorFicheros.cargarClientes();
        contReg = 0;
        actualizarLista();
    }

    private void actualizarLista() {
        javafx.collections.ObservableList<String> items = javafx.collections.FXCollections.observableArrayList();
        for (Cliente c : clientes)
            items.add(c.getDni() + " | " + c.getNombre() + " " + c.getApellidos());
        listaRegistros.setItems(items);
        if (contReg < clientes.size()) listaRegistros.getSelectionModel().select(contReg);
    }

    private void actualizarCampos() {
        Cliente c = clientes.get(contReg);
        campoDni.setText(String.valueOf(c.getDni()));
        campoNombre.setText(c.getNombre());
        campoApellidos.setText(c.getApellidos());
        campoTelefono.setText(c.getTelefono());
        campoEmail.setText(c.getEmail());
        campoFechaRegistro.setText(c.getFechaRegistro());
        checkActivo.setSelected(c.isActivo());
        campoRegistro.setText(contReg + "/" + (clientes.size() - 1));
    }

    private int buscarCliente(int dni) {
        for (int i = 0; i < clientes.size(); i++)
            if (clientes.get(i).getDni() == dni) return i;
        return -1;
    }

    @FXML
    private void darDeAlta(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            if (buscarCliente(dni) != -1) { campoMensaje.setText("Ya existe un cliente con ese DNI"); return; }
            if (campoNombre.getText().isEmpty()) { campoMensaje.setText("El nombre es obligatorio"); return; }
            String fecha = campoFechaRegistro.getText().isEmpty()
                ? java.time.LocalDate.now().toString() : campoFechaRegistro.getText();
            clientes.add(new Cliente(dni, campoNombre.getText(), campoApellidos.getText(),
                campoTelefono.getText(), campoEmail.getText(), fecha, checkActivo.isSelected()));
            GestorFicheros.guardarClientes(clientes);
            cargarDesdeFichero();
            contReg = clientes.size() - 1;
            actualizarCampos();
            campoMensaje.setText("Cliente dado de alta: DNI " + dni);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El DNI debe ser un numero entero");
        }
    }

    @FXML
    private void darDeBaja(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI del cliente"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            int idx = buscarCliente(dni);
            if (idx == -1) { campoMensaje.setText("No existe cliente con DNI: " + dni); return; }
            clientes.remove(idx);
            GestorFicheros.guardarClientes(clientes);
            campoMensaje.setText("Cliente DNI " + dni + " eliminado");
            cargarDesdeFichero();
            if (!clientes.isEmpty()) actualizarCampos(); else limpiarCampos(event);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El DNI debe ser un numero entero");
        }
    }

    @FXML
    private void modificarDatos(ActionEvent event) {
        if (campoDni.getText().isEmpty()) { campoMensaje.setText("Introduce el DNI del cliente"); return; }
        try {
            int dni = Integer.parseInt(campoDni.getText());
            int idx = buscarCliente(dni);
            if (idx == -1) { campoMensaje.setText("No existe cliente con DNI: " + dni); return; }
            Cliente c = clientes.get(idx);
            c.setNombre(campoNombre.getText());
            c.setApellidos(campoApellidos.getText());
            c.setTelefono(campoTelefono.getText());
            c.setEmail(campoEmail.getText());
            c.setFechaRegistro(campoFechaRegistro.getText());
            c.setActivo(checkActivo.isSelected());
            GestorFicheros.guardarClientes(clientes);
            cargarDesdeFichero();
            contReg = buscarCliente(dni);
            actualizarCampos();
            campoMensaje.setText("Cliente DNI " + dni + " modificado");
        } catch (NumberFormatException e) {
            campoMensaje.setText("El DNI debe ser un numero entero");
        }
    }

    @FXML private void irAprimero(ActionEvent event)   { if (!clientes.isEmpty()) { contReg = 0; actualizarCampos(); } }
    @FXML private void irAanterior(ActionEvent event)  { if (!clientes.isEmpty()) { contReg = (contReg == 0) ? clientes.size()-1 : contReg-1; actualizarCampos(); } }
    @FXML private void irAsiguiente(ActionEvent event) { if (!clientes.isEmpty()) { contReg = (contReg < clientes.size()-1) ? contReg+1 : 0; actualizarCampos(); } }
    @FXML private void irAultimo(ActionEvent event)    { if (!clientes.isEmpty()) { contReg = clientes.size()-1; actualizarCampos(); } }

    @FXML
    private void limpiarCampos(ActionEvent event) {
        campoDni.setText(""); campoNombre.setText(""); campoApellidos.setText("");
        campoTelefono.setText(""); campoEmail.setText(""); campoFechaRegistro.setText("");
        checkActivo.setSelected(true); campoRegistro.setText(""); campoMensaje.setText("");
    }

    @FXML
    private void salir(ActionEvent event) { ((Stage) btnSalir.getScene().getWindow()).close(); }

    public static void datosEntrada(String us) { usuario = us; }
}
