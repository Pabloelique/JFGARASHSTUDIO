package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Cita implements Serializable {

    private int id;
    private int clienteDni;
    private int peluqueroDni;
    private String fechaHora;
    private String estado;
    private String notas;
    private int duracionEstimada;
    private boolean recordatorioEnviado;

    public Cita(int id, int clienteDni, int peluqueroDni, String fechaHora,
                String estado, String notas, int duracionEstimada) {
        this.id = id;
        this.clienteDni = clienteDni;
        this.peluqueroDni = peluqueroDni;
        this.fechaHora = fechaHora;
        this.estado = estado;
        this.notas = notas;
        this.duracionEstimada = duracionEstimada;
        this.recordatorioEnviado = false;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getClienteDni() { return clienteDni; }
    public void setClienteDni(int clienteDni) { this.clienteDni = clienteDni; }
    public int getPeluqueroDni() { return peluqueroDni; }
    public void setPeluqueroDni(int peluqueroDni) { this.peluqueroDni = peluqueroDni; }
    public String getFechaHora() { return fechaHora; }
    public void setFechaHora(String fechaHora) { this.fechaHora = fechaHora; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }
    public int getDuracionEstimada() { return duracionEstimada; }
    public void setDuracionEstimada(int d) { this.duracionEstimada = d; }
    public boolean isRecordatorioEnviado() { return recordatorioEnviado; }
    public void setRecordatorioEnviado(boolean r) { this.recordatorioEnviado = r; }

    public void confirmar() { this.estado = "Confirmada"; }
    public void cancelar()  { this.estado = "Cancelada"; }
    public void finalizar() { this.estado = "Finalizada"; }
    public boolean esActiva() { return "Pendiente".equals(estado) || "Confirmada".equals(estado); }

    @Override
    public String toString() { return id + " - " + fechaHora + " [" + estado + "]"; }
}
