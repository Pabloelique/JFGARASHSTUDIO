package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Cita;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GestionCitasController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private TextField campoId;
    @FXML private TextField campoClienteDni;
    @FXML private TextField campoPeluqueroDni;
    @FXML private TextField campoFechaHora;
    @FXML private ComboBox<String> comboEstado;
    @FXML private TextField campoNotas;
    @FXML private TextField campoDuracion;
    @FXML private TextField campoRegistro;
    @FXML private TextField campoMensaje;
    @FXML private Button btnSalir;
    @FXML private ListView<String> listaRegistros;

    private static String usuario;
    private ArrayList<Cita> citas = new ArrayList<>();
    private int contReg = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        comboEstado.setItems(FXCollections.observableArrayList("Pendiente", "Confirmada", "Cancelada", "Finalizada"));
        comboEstado.setValue("Pendiente");
        cargarDesdeFichero();
        if (!citas.isEmpty()) actualizarCampos();
        listaRegistros.setOnMouseClicked(e -> {
            int idx = listaRegistros.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && idx < citas.size()) { contReg = idx; actualizarCampos(); }
        });
    }

    private void cargarDesdeFichero() {
        citas = GestorFicheros.cargarCitas();
        contReg = 0;
        actualizarLista();
    }

    private void actualizarLista() {
        javafx.collections.ObservableList<String> items = javafx.collections.FXCollections.observableArrayList();
        for (Cita c : citas)
            items.add("ID:" + c.getId() + " | " + c.getFechaHora() + " | " + c.getEstado());
        listaRegistros.setItems(items);
        if (contReg < citas.size()) listaRegistros.getSelectionModel().select(contReg);
    }

    private void actualizarCampos() {
        Cita c = citas.get(contReg);
        campoId.setText(String.valueOf(c.getId()));
        campoClienteDni.setText(String.valueOf(c.getClienteDni()));
        campoPeluqueroDni.setText(String.valueOf(c.getPeluqueroDni()));
        campoFechaHora.setText(c.getFechaHora());
        comboEstado.setValue(c.getEstado());
        campoNotas.setText(c.getNotas());
        campoDuracion.setText(String.valueOf(c.getDuracionEstimada()));
        campoRegistro.setText(contReg + "/" + (citas.size() - 1));
    }

    private int buscarCita(int id) {
        for (int i = 0; i < citas.size(); i++)
            if (citas.get(i).getId() == id) return i;
        return -1;
    }

    @FXML
    private void darDeAlta(ActionEvent event) {
        if (campoClienteDni.getText().isEmpty() || campoPeluqueroDni.getText().isEmpty()) {
            campoMensaje.setText("DNI de cliente y peluquero son obligatorios"); return;
        }
        try {
            int clienteDni   = Integer.parseInt(campoClienteDni.getText());
            int peluqueroDni = Integer.parseInt(campoPeluqueroDni.getText());
            int duracion     = campoDuracion.getText().isEmpty() ? 30 : Integer.parseInt(campoDuracion.getText());
            String fechaHora = campoFechaHora.getText().isEmpty() ? "2024-01-01 10:00" : campoFechaHora.getText();
            int nuevoId = GestorFicheros.nextIdCita();
            citas.add(new Cita(nuevoId, clienteDni, peluqueroDni, fechaHora,
                comboEstado.getValue(), campoNotas.getText(), duracion));
            GestorFicheros.guardarCitas(citas);
            cargarDesdeFichero();
            contReg = citas.size() - 1;
            actualizarCampos();
            campoMensaje.setText("Cita registrada con ID: " + nuevoId);
        } catch (NumberFormatException e) {
            campoMensaje.setText("DNI y duracion deben ser numericos");
        }
    }

    @FXML
    private void darDeBaja(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID de la cita"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarCita(id);
            if (idx == -1) { campoMensaje.setText("No existe cita con ID: " + id); return; }
            citas.remove(idx);
            GestorFicheros.guardarCitas(citas);
            campoMensaje.setText("Cita ID " + id + " eliminada");
            cargarDesdeFichero();
            if (!citas.isEmpty()) actualizarCampos(); else limpiarCampos(event);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El ID debe ser un numero entero");
        }
    }

    @FXML
    private void modificarDatos(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID de la cita"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarCita(id);
            if (idx == -1) { campoMensaje.setText("No existe cita con ID: " + id); return; }
            Cita c = citas.get(idx);
            c.setClienteDni(Integer.parseInt(campoClienteDni.getText()));
            c.setPeluqueroDni(Integer.parseInt(campoPeluqueroDni.getText()));
            c.setFechaHora(campoFechaHora.getText());
            c.setEstado(comboEstado.getValue());
            c.setNotas(campoNotas.getText());
            c.setDuracionEstimada(campoDuracion.getText().isEmpty() ? 30 : Integer.parseInt(campoDuracion.getText()));
            GestorFicheros.guardarCitas(citas);
            cargarDesdeFichero();
            contReg = buscarCita(id);
            actualizarCampos();
            campoMensaje.setText("Cita ID " + id + " modificada");
        } catch (NumberFormatException e) {
            campoMensaje.setText("Los valores numericos son incorrectos");
        }
    }

    @FXML private void irAprimero(ActionEvent event)   { if (!citas.isEmpty()) { contReg = 0; actualizarCampos(); } }
    @FXML private void irAanterior(ActionEvent event)  { if (!citas.isEmpty()) { contReg = (contReg == 0) ? citas.size()-1 : contReg-1; actualizarCampos(); } }
    @FXML private void irAsiguiente(ActionEvent event) { if (!citas.isEmpty()) { contReg = (contReg < citas.size()-1) ? contReg+1 : 0; actualizarCampos(); } }
    @FXML private void irAultimo(ActionEvent event)    { if (!citas.isEmpty()) { contReg = citas.size()-1; actualizarCampos(); } }

    @FXML
    private void limpiarCampos(ActionEvent event) {
        campoId.setText(""); campoClienteDni.setText(""); campoPeluqueroDni.setText("");
        campoFechaHora.setText(""); comboEstado.setValue("Pendiente");
        campoNotas.setText(""); campoDuracion.setText("");
        campoRegistro.setText(""); campoMensaje.setText("");
    }

    @FXML
    private void salir(ActionEvent event) { ((Stage) btnSalir.getScene().getWindow()).close(); }

    public static void datosEntrada(String us) { usuario = us; }
}
