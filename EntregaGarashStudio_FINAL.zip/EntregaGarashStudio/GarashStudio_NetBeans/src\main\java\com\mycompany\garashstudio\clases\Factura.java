package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Factura implements Serializable {

    private int id;
    private int citaId;
    private String fecha;
    private double totalBase;
    private double iva;
    private double totalFinal;
    private String metodoPago;

    public Factura(int id, int citaId, String fecha, double totalBase,
                   double iva, String metodoPago) {
        this.id = id;
        this.citaId = citaId;
        this.fecha = fecha;
        this.totalBase = totalBase;
        this.iva = iva;
        this.metodoPago = metodoPago;
        this.totalFinal = totalBase + (totalBase * iva / 100.0);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCitaId() { return citaId; }
    public void setCitaId(int citaId) { this.citaId = citaId; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public double getTotalBase() { return totalBase; }
    public void setTotalBase(double totalBase) { this.totalBase = totalBase; }

    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }

    public double getTotalFinal() { return totalFinal; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }

    public void calcularTotal() {
        this.totalFinal = totalBase + (totalBase * iva / 100.0);
    }
}
