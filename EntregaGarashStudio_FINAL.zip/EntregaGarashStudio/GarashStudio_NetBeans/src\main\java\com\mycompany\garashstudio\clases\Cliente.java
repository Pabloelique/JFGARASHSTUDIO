package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Cliente implements Serializable {

    private int dni;
    private String nombre;
    private String apellidos;
    private String telefono;
    private String email;
    private String fechaRegistro;
    private boolean activo;

    public Cliente(int dni, String nombre, String apellidos, String telefono,
                   String email, String fechaRegistro, boolean activo) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.email = email;
        this.fechaRegistro = fechaRegistro;
        this.activo = activo;
    }

    public int getDni() { return dni; }
    public void setDni(int dni) { this.dni = dni; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellidos() { return apellidos; }
    public void setApellidos(String apellidos) { this.apellidos = apellidos; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(String fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public void desactivar() { this.activo = false; }

    @Override
    public String toString() {
        return dni + " - " + nombre + " " + apellidos;
    }
}
