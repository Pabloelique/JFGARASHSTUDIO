package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Usuario;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class LoginRegistroController implements Initializable {

    @FXML private Button btnModoLogin;
    @FXML private Button btnModoRegistro;
    @FXML private Pane panelLogin;
    @FXML private TextField campoLoginUsuario;
    @FXML private PasswordField campoLoginPassword;
    @FXML private Button btnLogin;
    @FXML private Button btnVerUsuarios;
    @FXML private Pane panelRegistro;
    @FXML private TextField campoRegNombre;
    @FXML private TextField campoRegApellidos;
    @FXML private TextField campoRegTelefono;
    @FXML private ComboBox<String> comboRegTipo;
    @FXML private TextField campoRegEmail;
    @FXML private PasswordField campoRegPassword;
    @FXML private Button btnRegistrar;
    @FXML private TextField campoMensaje;

    private static final String ESTILO_ACTIVO =
        "-fx-background-color: #7B1FA2; -fx-text-fill: white; -fx-font-weight: bold;"
        + " -fx-font-size: 12; -fx-background-radius: 8; -fx-cursor: hand;";
    private static final String ESTILO_INACTIVO =
        "-fx-background-color: transparent; -fx-text-fill: #CE93D8;"
        + " -fx-border-color: #7B1FA2; -fx-border-radius: 8; -fx-background-radius: 8;"
        + " -fx-font-size: 12; -fx-cursor: hand;";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        comboRegTipo.setItems(FXCollections.observableArrayList("Admin", "Recepcionista"));
        comboRegTipo.setValue("Recepcionista");
        mostrarLogin(null);
        // Sin auto-relleno: el usuario introduce sus datos manualmente
    }

    @FXML
    private void mostrarLogin(ActionEvent event) {
        panelLogin.setVisible(true);
        panelRegistro.setVisible(false);
        btnModoLogin.setStyle(ESTILO_ACTIVO);
        btnModoRegistro.setStyle(ESTILO_INACTIVO);
        campoMensaje.setText("");
    }

    @FXML
    private void mostrarRegistro(ActionEvent event) {
        panelLogin.setVisible(false);
        panelRegistro.setVisible(true);
        btnModoLogin.setStyle(ESTILO_INACTIVO);
        btnModoRegistro.setStyle(ESTILO_ACTIVO);
        campoMensaje.setText("");
    }

    @FXML
    private void iniciarSesion(ActionEvent event) {
        String usuario = campoLoginUsuario.getText().trim();
        String pass    = campoLoginPassword.getText();
        if (usuario.isEmpty() || pass.isEmpty()) {
            campoMensaje.setText("Introduce usuario y contrasena"); return;
        }
        ArrayList<Usuario> usuarios = GestorFicheros.cargarUsuarios();
        for (Usuario u : usuarios) {
            if (u.getNombre().equals(usuario) && u.getPassword().equals(pass) && u.isActivo()) {
                abrirVentanaInicial(u.getNombre(), u.getTipo());
                return;
            }
        }
        campoMensaje.setText("Usuario o contrasena incorrectos");
    }

    @FXML
    private void registrarse(ActionEvent event) {
        String nombre    = campoRegNombre.getText().trim();
        String apellidos = campoRegApellidos.getText().trim();
        String telefono  = campoRegTelefono.getText().trim();
        String email     = campoRegEmail.getText().trim();
        String pass      = campoRegPassword.getText();
        String tipo      = comboRegTipo.getValue();

        if (nombre.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            campoMensaje.setText("Nombre, email y contrasena son obligatorios"); return;
        }
        if (!email.contains("@")) { campoMensaje.setText("Introduce un email valido"); return; }
        if (pass.length() < 4)    { campoMensaje.setText("La contrasena debe tener al menos 4 caracteres"); return; }

        ArrayList<Usuario> usuarios = GestorFicheros.cargarUsuarios();
        for (Usuario u : usuarios) {
            if (u.getEmail().equals(email)) { campoMensaje.setText("Ya existe una cuenta con ese email"); return; }
        }
        if (nombre.equalsIgnoreCase("admin") && !usuarios.isEmpty()) {
            campoMensaje.setText("El nombre 'admin' esta reservado"); return;
        }

        usuarios.add(new Usuario(nombre, apellidos, telefono, email, pass, tipo,
            java.time.LocalDate.now().toString(), true));
        GestorFicheros.guardarUsuarios(usuarios);

        // Dialogo de confirmacion visible
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Cuenta creada");
        alert.setHeaderText("Usuario creado con exito");
        alert.setContentText(
            "Bienvenido a Garash Studio, " + nombre + "!\n\n"
            + "Tipo de cuenta : " + tipo + "\n"
            + "Ya puedes iniciar sesion con tu usuario.");
        alert.getDialogPane().setStyle("-fx-background-color: #1A0030;");
        alert.getDialogPane().lookup(".content.label")
             .setStyle("-fx-text-fill: #CE93D8; -fx-font-size: 13;");
        alert.showAndWait();

        limpiarRegistro();
        mostrarLogin(null);
    }

    private void limpiarRegistro() {
        campoRegNombre.setText(""); campoRegApellidos.setText(""); campoRegTelefono.setText("");
        campoRegEmail.setText(""); campoRegPassword.setText(""); comboRegTipo.setValue("Recepcionista");
    }

    @FXML
    private void verUsuarios(ActionEvent event) {
        ArrayList<Usuario> usuarios = GestorFicheros.cargarUsuarios();
        StringBuilder sb = new StringBuilder("Usuarios del sistema\n\n");
        sb.append(String.format("%-20s %-15s %s\n", "Usuario", "Categoria", "Estado"));
        sb.append("-".repeat(42)).append("\n");
        for (Usuario u : usuarios)
            sb.append(String.format("%-20s %-15s %s\n",
                u.getNombre(), u.getTipo(), u.isActivo() ? "Activo" : "Inactivo"));
        if (usuarios.isEmpty()) sb.append("No hay usuarios registrados.");

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Usuarios del sistema");
        alert.setHeaderText("Usuarios del sistema");
        alert.setContentText(sb.toString());
        alert.getDialogPane().setStyle("-fx-background-color: #1A0030; -fx-font-family: monospace; -fx-font-size: 12px;");
        alert.getDialogPane().lookup(".content.label").setStyle("-fx-text-fill: #E0C8FF; -fx-font-family: monospace;");
        alert.showAndWait();
    }

    private void abrirVentanaInicial(String nombre, String tipo) {
        try {
            VentanaInicialController.datosEntrada(nombre, tipo);
            FXMLLoader loader = new FXMLLoader(App.class.getResource("VentanaInicial.fxml"));
            Scene escena = new Scene(loader.load());
            Stage escenario = new Stage();
            escenario.setTitle("Garash Studio");
            escenario.setResizable(false);
            escenario.setScene(escena);
            escenario.show();
            escenario.setOnCloseRequest(ev -> {
                ev.consume();
                modulos.FuncionesGraficas.warning("Atencion", "Use el boton Salir para cerrar la aplicacion");
            });
            ((Stage) btnLogin.getScene().getWindow()).close();
        } catch (IOException e) {
            campoMensaje.setText("Error al abrir la aplicacion: " + e.getMessage());
        }
    }
}
