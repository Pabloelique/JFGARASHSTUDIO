package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class LineaFactura implements Serializable {

    private int id;
    private int facturaId;
    private String tipo;
    private String descripcion;
    private double cantidad;

    public LineaFactura(int id, int facturaId, String tipo,
                        String descripcion, double cantidad) {
        this.id = id;
        this.facturaId = facturaId;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getFacturaId() { return facturaId; }
    public void setFacturaId(int facturaId) { this.facturaId = facturaId; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public double getCantidad() { return cantidad; }
    public void setCantidad(double cantidad) { this.cantidad = cantidad; }
}
