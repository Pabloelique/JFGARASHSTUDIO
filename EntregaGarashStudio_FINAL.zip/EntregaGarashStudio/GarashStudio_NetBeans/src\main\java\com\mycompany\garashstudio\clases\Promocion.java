package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Promocion implements Serializable {

    private int id;
    private String nombre;
    private String descripcion;
    private double descuentoPorcentaje;
    private String fechaInicio;
    private String fechaFin;
    private boolean activa;

    public Promocion(int id, String nombre, String descripcion,
                     double descuentoPorcentaje, String fechaInicio, String fechaFin) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.descuentoPorcentaje = descuentoPorcentaje;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.activa = true;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public double getDescuentoPorcentaje() { return descuentoPorcentaje; }
    public void setDescuentoPorcentaje(double d) { this.descuentoPorcentaje = d; }

    public String getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(String fechaInicio) { this.fechaInicio = fechaInicio; }

    public String getFechaFin() { return fechaFin; }
    public void setFechaFin(String fechaFin) { this.fechaFin = fechaFin; }

    public boolean isActiva() { return activa; }
    public void activar() { this.activa = true; }
    public void desactivar() { this.activa = false; }
}
