package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public abstract class Empleado implements Serializable {

    private int dni;
    private String nombre;
    private String telefono;
    private boolean activo;
    private double salarioBase;
    private String fechaContratacion;

    public Empleado(int dni, String nombre, String telefono,
                    double salarioBase, String fechaContratacion) {
        this.dni = dni;
        this.nombre = nombre;
        this.telefono = telefono;
        this.activo = true;
        this.salarioBase = salarioBase;
        this.fechaContratacion = fechaContratacion;
    }

    public abstract double calcularNomina();
    public abstract String getTipo();

    public int getDni() { return dni; }
    public void setDni(int dni) { this.dni = dni; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public double getSalarioBase() { return salarioBase; }
    public void setSalarioBase(double salarioBase) { this.salarioBase = salarioBase; }

    public String getFechaContratacion() { return fechaContratacion; }
    public void setFechaContratacion(String fechaContratacion) { this.fechaContratacion = fechaContratacion; }

    public void desactivar() { this.activo = false; }

    @Override
    public String toString() {
        return dni + " - " + nombre + " (" + getTipo() + ")";
    }
}
