package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.*;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;

public class RecordatorioService {

    private static final String TWILIO_SID   = "";
    private static final String TWILIO_TOKEN = "";
    private static final String TWILIO_FROM  = "";
    private static final String PREFIJO_PAIS = "+34";

    public static void comprobarRecordatorios() {
        new Thread(() -> {
            List<String[]> citas = obtenerCitas24h();
            if (citas.isEmpty()) return;
            StringBuilder sb = new StringBuilder();
            for (String[] c : citas) {
                sb.append("* ").append(c[0])
                  .append("  |  ").append(c[1])
                  .append("  |  Tel: ").append(c[2].isEmpty() ? "sin telefono" : c[2])
                  .append("\n");
                if (!TWILIO_SID.isEmpty() && !c[2].isEmpty()) {
                    String tel = c[2].startsWith("+") ? c[2] : PREFIJO_PAIS + c[2];
                    String msg = "Recordatorio Garash Studio: Tienes cita el " + c[0]
                               + ". Para cancelar llama al salon. Gracias!";
                    enviarSms(tel, msg);
                }
                marcarRecordatorio(Integer.parseInt(c[3]));
            }
            String texto = sb.toString();
            Platform.runLater(() -> {
                TextArea area = new TextArea(texto);
                area.setEditable(false);
                area.setStyle("-fx-control-inner-background: #1A0030; -fx-text-fill: #CE93D8;");
                area.setPrefHeight(160);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Recordatorios -- proximas 24 horas");
                alert.setHeaderText("Citas programadas para las proximas 24 horas:");
                alert.getDialogPane().setContent(area);
                alert.getDialogPane().setStyle("-fx-background-color: #0D0010;");
                alert.showAndWait();
            });
        }).start();
    }

    private static List<String[]> obtenerCitas24h() {
        List<String[]> lista = new ArrayList<>();
        ArrayList<Cita> citas       = GestorFicheros.cargarCitas();
        ArrayList<Cliente> clientes = GestorFicheros.cargarClientes();
        LocalDateTime ahora  = LocalDateTime.now();
        LocalDateTime limite = ahora.plusHours(24);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        for (Cita c : citas) {
            if (!c.getEstado().equals("Pendiente") && !c.getEstado().equals("Confirmada")) continue;
            if (c.isRecordatorioEnviado()) continue;
            try {
                LocalDateTime fechaCita = LocalDateTime.parse(c.getFechaHora(), fmt);
                if (!fechaCita.isAfter(ahora) || !fechaCita.isBefore(limite)) continue;
            } catch (Exception e) { continue; }
            String nombre = "Desconocido", telefono = "";
            for (Cliente cl : clientes) {
                if (cl.getDni() == c.getClienteDni()) { nombre = cl.getNombre(); telefono = cl.getTelefono(); break; }
            }
            lista.add(new String[]{ c.getFechaHora(), nombre, telefono, String.valueOf(c.getId()) });
        }
        return lista;
    }

    private static void marcarRecordatorio(int citaId) {
        ArrayList<Cita> citas = GestorFicheros.cargarCitas();
        for (Cita c : citas) {
            if (c.getId() == citaId) { c.setRecordatorioEnviado(true); break; }
        }
        GestorFicheros.guardarCitas(citas);
    }

    private static void enviarSms(String to, String body) {
        try {
            String auth = Base64.getEncoder().encodeToString(
                (TWILIO_SID + ":" + TWILIO_TOKEN).getBytes(StandardCharsets.UTF_8));
            String form = "From=" + URLEncoder.encode(TWILIO_FROM, StandardCharsets.UTF_8)
                        + "&To="   + URLEncoder.encode(to,          StandardCharsets.UTF_8)
                        + "&Body=" + URLEncoder.encode(body,         StandardCharsets.UTF_8);
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create("https://api.twilio.com/2010-04-01/Accounts/" + TWILIO_SID + "/Messages.json"))
                .header("Authorization", "Basic " + auth)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();
            HttpResponse<String> resp = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString());
            System.out.println("SMS enviado a " + to + " | status " + resp.statusCode());
        } catch (Exception e) {
            System.err.println("Error enviando SMS a " + to + ": " + e.getMessage());
        }
    }
}
