package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.*;
import java.io.*;
import java.util.ArrayList;

public class GestorFicheros {

    private static final String DIR = System.getProperty("user.home") + "/GarashStudio/";
    private static final String F_CLIENTES  = DIR + "clientes.dat";
    private static final String F_EMPLEADOS = DIR + "empleados.dat";
    private static final String F_CITAS     = DIR + "citas.dat";
    private static final String F_PRODUCTOS = DIR + "productos.dat";
    private static final String F_SERVICIOS = DIR + "servicios.dat";
    private static final String F_USUARIOS  = DIR + "usuarios.dat";

    public static void inicializar() {
        new File(DIR).mkdirs();
        if (!new File(F_CLIENTES).exists())  guardarClientes(datosInicialesClientes());
        if (!new File(F_EMPLEADOS).exists()) guardarEmpleados(datosInicialesEmpleados());
        if (!new File(F_CITAS).exists())     guardarCitas(datosInicialesCitas());
        if (!new File(F_PRODUCTOS).exists()) guardarProductos(datosInicialesProductos());
        if (!new File(F_SERVICIOS).exists()) guardarServicios(datosInicialesServicios());
        if (!new File(F_USUARIOS).exists())  guardarUsuarios(datosInicialesUsuarios());
    }

    public static ArrayList<Cliente>  cargarClientes()  { return cargar(F_CLIENTES); }
    public static ArrayList<Empleado> cargarEmpleados() { return cargar(F_EMPLEADOS); }
    public static ArrayList<Cita>     cargarCitas()     { return cargar(F_CITAS); }
    public static ArrayList<Producto> cargarProductos() { return cargar(F_PRODUCTOS); }
    public static ArrayList<Servicio> cargarServicios() { return cargar(F_SERVICIOS); }
    public static ArrayList<Usuario>  cargarUsuarios()  { return cargar(F_USUARIOS); }

    public static void guardarClientes(ArrayList<Cliente> l)   { guardar(l, F_CLIENTES); }
    public static void guardarEmpleados(ArrayList<Empleado> l) { guardar(l, F_EMPLEADOS); }
    public static void guardarCitas(ArrayList<Cita> l)         { guardar(l, F_CITAS); }
    public static void guardarProductos(ArrayList<Producto> l) { guardar(l, F_PRODUCTOS); }
    public static void guardarServicios(ArrayList<Servicio> l) { guardar(l, F_SERVICIOS); }
    public static void guardarUsuarios(ArrayList<Usuario> l)   { guardar(l, F_USUARIOS); }

    public static int nextIdCita()     { return cargarCitas().stream().mapToInt(Cita::getId).max().orElse(0) + 1; }
    public static int nextIdProducto() { return cargarProductos().stream().mapToInt(Producto::getId).max().orElse(0) + 1; }
    public static int nextIdServicio() { return cargarServicios().stream().mapToInt(Servicio::getId).max().orElse(0) + 1; }

    @SuppressWarnings("unchecked")
    private static <T> ArrayList<T> cargar(String ruta) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            return (ArrayList<T>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    private static <T> void guardar(ArrayList<T> lista, String ruta) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.err.println("Error al guardar " + ruta + ": " + e.getMessage());
        }
    }

    // ── 20 Clientes (18 activos, 2 inactivos) ─────────────────────────────────
    private static ArrayList<Cliente> datosInicialesClientes() {
        ArrayList<Cliente> l = new ArrayList<>();
        l.add(new Cliente(11000001, "Laura",    "Garcia Ruiz",      "600001001", "laura.garcia@email.com",    "2024-01-05", true));
        l.add(new Cliente(22000002, "Miguel",   "Lopez Sanchez",    "600002002", "miguel.lopez@email.com",    "2024-01-20", true));
        l.add(new Cliente(33000003, "Carmen",   "Martinez Gil",     "600003003", "carmen.martinez@email.com", "2024-02-10", true));
        l.add(new Cliente(44000004, "Roberto",  "Fernandez Mora",   "600004004", "roberto.f@email.com",       "2024-02-25", true));
        l.add(new Cliente(55000005, "Elena",    "Diaz Romero",      "600005005", "elena.diaz@email.com",      "2024-03-08", true));
        l.add(new Cliente(66000006, "Pablo",    "Jimenez Torres",   "600006006", "pablo.j@email.com",         "2024-03-22", true));
        l.add(new Cliente(77000007, "Lucia",    "Morales Vega",     "600007007", "lucia.m@email.com",         "2024-04-01", true));
        l.add(new Cliente(88000008, "Javier",   "Ruiz Castellano",  "600008008", "javier.r@email.com",        "2024-04-15", true));
        l.add(new Cliente(99000009, "Maria",    "Perez Blanco",     "600009009", "maria.perez@email.com",     "2024-05-03", true));
        l.add(new Cliente(10100010, "Andres",   "Gomez Navarro",    "600010010", "andres.g@email.com",        "2024-05-18", true));
        l.add(new Cliente(11100011, "Sara",     "Herrero Campos",   "600011011", "sara.h@email.com",          "2024-06-02", true));
        l.add(new Cliente(12100012, "Diego",    "Castro Rey",       "600012012", "diego.c@email.com",         "2024-06-20", true));
        l.add(new Cliente(13100013, "Nuria",    "Alonso Mendez",    "600013013", "nuria.a@email.com",         "2024-07-05", true));
        l.add(new Cliente(14100014, "Fernando", "Ortiz Leal",       "600014014", "fernando.o@email.com",      "2024-07-22", false));
        l.add(new Cliente(15100015, "Marta",    "Iglesias Cano",    "600015015", "marta.i@email.com",         "2024-08-10", true));
        l.add(new Cliente(16100016, "Alberto",  "Ramos Delgado",    "600016016", "alberto.r@email.com",       "2024-08-28", false));
        l.add(new Cliente(17100017, "Patricia", "Molina Serrano",   "600017017", "patricia.m@email.com",      "2024-09-14", true));
        l.add(new Cliente(18100018, "Victor",   "Reyes Fuentes",    "600018018", "victor.r@email.com",        "2024-09-30", true));
        l.add(new Cliente(19100019, "Beatriz",  "Cruz Dominguez",   "600019019", "beatriz.c@email.com",       "2025-01-10", true));
        l.add(new Cliente(20100020, "Hector",   "Vargas Pena",      "600020020", "hector.v@email.com",        "2026-05-01", true));
        return l;
    }

    // ── 20 Empleados (12 Peluqueros + 8 Recepcionistas) ──────────────────────
    private static ArrayList<Empleado> datosInicialesEmpleados() {
        ArrayList<Empleado> l = new ArrayList<>();
        l.add(new Peluquero(    11111111, "Maria Perez",     "600100200", 1400.0, "2022-09-01", "Colorimetria"));
        l.add(new Peluquero(    33333333, "Elena Ruiz",      "622300400", 1300.0, "2021-06-01", "Corte y peinado"));
        l.add(new Peluquero(    55555501, "Carla Suarez",    "600101201", 1350.0, "2020-03-15", "Mechas y balayage"));
        l.add(new Peluquero(    55555502, "Jorge Blanco",    "600102202", 1250.0, "2021-11-01", "Barba caballero"));
        l.add(new Peluquero(    55555503, "Ana Vidal",       "600103203", 1400.0, "2019-06-01", "Tratamientos capilares"));
        l.add(new Peluquero(    55555504, "Luis Mora",       "600104204", 1200.0, "2022-02-14", "Corte moderno"));
        l.add(new Peluquero(    55555505, "Isabel Soler",    "600105205", 1450.0, "2018-09-01", "Coloracion avanzada"));
        l.add(new Peluquero(    55555506, "Raul Romero",     "600106206", 1150.0, "2023-04-01", "Peinados de novia"));
        l.add(new Peluquero(    55555507, "Cristina Lara",   "600107207", 1300.0, "2020-07-15", "Alisados"));
        l.add(new Peluquero(    55555508, "Oscar Medina",    "600108208", 1250.0, "2021-09-01", "Extensiones"));
        l.add(new Peluquero(    55555509, "Pilar Rubio",     "600109209", 1350.0, "2022-05-01", "Keratina"));
        l.add(new Peluquero(    55555510, "Marco Rueda",     "600110210", 1200.0, "2023-01-15", "Corte clasico"));
        l.add(new Recepcionista(22222222, "Pedro Gomez",     "611200300", 1100.0, "2023-01-15", "Manana"));
        l.add(new Recepcionista(44444444, "Javier Mora",     "633400500", 1050.0, "2023-09-10", "Tarde"));
        l.add(new Recepcionista(66666601, "Rosa Campos",     "600201301", 1000.0, "2022-06-01", "Manana"));
        l.add(new Recepcionista(66666602, "Daniel Torres",   "600202302", 1050.0, "2022-10-01", "Tarde"));
        l.add(new Recepcionista(66666603, "Silvia Pino",     "600203303", 1000.0, "2023-03-01", "Manana"));
        l.add(new Recepcionista(66666604, "Ruben Vela",      "600204304", 1050.0, "2023-07-01", "Tarde"));
        l.add(new Recepcionista(66666605, "Lorena Cid",      "600205305", 1000.0, "2024-01-01", "Manana"));
        l.add(new Recepcionista(66666606, "Adrian Diez",     "600206306", 1050.0, "2024-04-01", "Tarde"));
        return l;
    }

    // ── 20 Citas ──────────────────────────────────────────────────────────────
    // Laura (11000001):  6 Finalizadas -> tiene tarjeta fidelidad (umbral 5)
    // Miguel (22000002): 5 Finalizadas -> tiene tarjeta fidelidad (umbral 5)
    // Carmen (33000003): 2 Finalizadas + 1 Cancelada -> sin tarjeta
    // Resto: estados variados, proximas 7 dias y pasadas
    private static ArrayList<Cita> datosInicialesCitas() {
        ArrayList<Cita> l = new ArrayList<>();
        l.add(new Cita( 1, 11000001, 11111111, "2025-09-10 10:00", "Finalizada", "Tinte completo",      90));
        l.add(new Cita( 2, 11000001, 33333333, "2025-10-15 11:00", "Finalizada", "Mechas balayage",    120));
        l.add(new Cita( 3, 11000001, 55555501, "2025-11-20 10:00", "Finalizada", "Corte y color",       60));
        l.add(new Cita( 4, 11000001, 11111111, "2025-12-05 10:00", "Finalizada", "Tinte raices",        45));
        l.add(new Cita( 5, 11000001, 55555505, "2026-01-10 09:00", "Finalizada", "Alisado japones",    180));
        l.add(new Cita( 6, 11000001, 11111111, "2026-02-14 10:00", "Finalizada", "Peinado de fiesta",   60));
        l.add(new Cita( 7, 11000001, 33333333, "2026-05-14 11:00", "Confirmada", "Corte puntas",        30));
        l.add(new Cita( 8, 22000002, 33333333, "2025-08-01 12:00", "Finalizada", "Corte caballero",     30));
        l.add(new Cita( 9, 22000002, 55555502, "2025-09-15 12:00", "Finalizada", "Barba completa",      30));
        l.add(new Cita(10, 22000002, 11111111, "2025-10-20 12:00", "Finalizada", "Tinte castano",       90));
        l.add(new Cita(11, 22000002, 55555504, "2025-11-25 12:00", "Finalizada", "Tratamiento capilar", 45));
        l.add(new Cita(12, 22000002, 33333333, "2025-12-20 12:00", "Finalizada", "Corte moderno",       30));
        l.add(new Cita(13, 33000003, 11111111, "2025-07-10 09:00", "Finalizada", "Mechas completas",   120));
        l.add(new Cita(14, 33000003, 33333333, "2025-10-05 09:00", "Finalizada", "Corte y peinado",     60));
        l.add(new Cita(15, 33000003, 11111111, "2026-03-15 09:00", "Cancelada",  "Tinte completo",      90));
        l.add(new Cita(16, 44000004, 55555506, "2026-05-14 15:00", "Pendiente",  "Peinado de novia",    90));
        l.add(new Cita(17, 55000005, 55555503, "2026-05-15 10:00", "Pendiente",  "Tratamiento capilar", 45));
        l.add(new Cita(18, 66000006, 11111111, "2026-05-16 11:00", "Confirmada", "Tinte completo",      90));
        l.add(new Cita(19, 77000007, 33333333, "2026-05-20 10:00", "Pendiente",  "Mechas balayage",    120));
        l.add(new Cita(20, 88000008, 55555507, "2026-04-01 10:00", "Cancelada",  "Alisado japones",    180));
        return l;
    }

    // ── 20 Productos (5 con stock bajo) ───────────────────────────────────────
    private static ArrayList<Producto> datosInicialesProductos() {
        ArrayList<Producto> l = new ArrayList<>();
        l.add(new Producto( 1, "Champu LOreal Professional 300ml",    6.80,  12.90, 22,  5, "LOreal Espana"));
        l.add(new Producto( 2, "Tinte Wella Koleston 7/0",            5.20,  11.50, 28, 10, "Wella Distribuciones"));
        l.add(new Producto( 3, "Mascarilla Redken All Soft",           9.50,  18.95, 14,  5, "Redken Iberia"));
        l.add(new Producto( 4, "Laca Schwarzkopf OSiS",               4.10,   8.50, 19,  8, "Schwarzkopf Professional"));
        l.add(new Producto( 5, "Oxidante 30 vol Salerm 1000ml",       3.80,   7.00,  2, 10, "Salerm Cosmetics"));
        l.add(new Producto( 6, "Serum Moroccanoil 100ml",            13.00,  25.00, 11,  4, "Moroccanoil International"));
        l.add(new Producto( 7, "Acondicionador Kerastase 250ml",      8.80,  17.50,  7,  5, "Kerastase France"));
        l.add(new Producto( 8, "Tinte Igora Royal 60ml",              5.50,  12.00, 33, 10, "Schwarzkopf Professional"));
        l.add(new Producto( 9, "Champu Kerastase Nutritive",         11.50,  22.00,  3,  5, "Kerastase France"));
        l.add(new Producto(10, "Spray termoprotector Redken",         7.20,  14.00, 18,  5, "Redken Iberia"));
        l.add(new Producto(11, "Cera modeladora Wax",                 4.50,   9.00, 25,  8, "Wella Distribuciones"));
        l.add(new Producto(12, "Tonica Revlon 60ml",                  3.20,   7.50, 40, 10, "Revlon Professional"));
        l.add(new Producto(13, "Bleach Powder Wella",                 8.00,  16.00,  4, 10, "Wella Distribuciones"));
        l.add(new Producto(14, "Mascarilla Alfaparf Semi di Lino",   10.00,  20.00, 16,  5, "Alfaparf Italia"));
        l.add(new Producto(15, "Champu anticaspa Ducray",             7.50,  15.00,  2,  8, "Pierre Fabre Iberica"));
        l.add(new Producto(16, "Botox capilar BTX Gold",             20.00,  45.00,  9,  5, "BTX Cosmetica"));
        l.add(new Producto(17, "Argan oil Bioilba 50ml",             12.00,  24.00,  1,  4, "Bioilba Espana"));
        l.add(new Producto(18, "Papel de aluminio rollo",             2.50,   5.00, 50, 10, "Suministros Peluqueria"));
        l.add(new Producto(19, "Guantes latex M 100u",               3.00,   6.00, 30, 20, "Suministros Peluqueria"));
        l.add(new Producto(20, "Peine Hercules Sagemann",             8.00,  16.00, 15,  5, "Hercules Sagemann"));
        return l;
    }

    // ── 20 Servicios ──────────────────────────────────────────────────────────
    private static ArrayList<Servicio> datosInicialesServicios() {
        ArrayList<Servicio> l = new ArrayList<>();
        l.add(new Servicio( 1, "Corte de cabello mujer",    22.0,  30, "Corte personalizado dama",              "Corte"));
        l.add(new Servicio( 2, "Corte de cabello hombre",   15.0,  20, "Corte caballero clasico o moderno",     "Corte"));
        l.add(new Servicio( 3, "Corte y peinado",           30.0,  45, "Corte mas secado y peinado final",      "Corte"));
        l.add(new Servicio( 4, "Tinte completo",            55.0,  90, "Coloracion completa profesional",       "Color"));
        l.add(new Servicio( 5, "Mechas y balayage",         75.0, 120, "Tecnica de aclarado progresivo",        "Color"));
        l.add(new Servicio( 6, "Tinte raices",              35.0,  45, "Retoque de raices sin aclarar",         "Color"));
        l.add(new Servicio( 7, "Decoloracion completa",     65.0,  90, "Aclarado total del cabello",            "Color"));
        l.add(new Servicio( 8, "Peinado de fiesta",         40.0,  60, "Recogido o semirecogido para eventos",  "Peinado"));
        l.add(new Servicio( 9, "Peinado de novia",          80.0, 120, "Peinado especial dia de boda",          "Peinado"));
        l.add(new Servicio(10, "Tratamiento hidratante",    30.0,  45, "Mascarilla y tratamiento nutritivo",    "Tratamiento"));
        l.add(new Servicio(11, "Alisado japones",          120.0, 180, "Alisado permanente larga duracion",     "Tratamiento"));
        l.add(new Servicio(12, "Botox capilar",             90.0, 120, "Tratamiento reparador intensivo",       "Tratamiento"));
        l.add(new Servicio(13, "Keratina brasilena",       100.0, 150, "Alisado con queratina natural",         "Tratamiento"));
        l.add(new Servicio(14, "Manicura clasica",          15.0,  30, "Limado y pintado de unas",              "Unas"));
        l.add(new Servicio(15, "Manicura con gel",          25.0,  45, "Unas de gel larga duracion",            "Unas"));
        l.add(new Servicio(16, "Nail art",                  35.0,  60, "Disenos personalizados en unas",        "Unas"));
        l.add(new Servicio(17, "Depilacion facial",         12.0,  15, "Depilacion ceja o labio",               "Depilacion"));
        l.add(new Servicio(18, "Masaje craneal",            20.0,  20, "Masaje relajante cuero cabelludo",      "Extra"));
        l.add(new Servicio(19, "Lavado y secado",           12.0,  20, "Lavado con champu y secado basico",     "Basico"));
        l.add(new Servicio(20, "Permanente rizadora",       50.0,  90, "Rizos o forma permanente",              "Tratamiento"));
        return l;
    }

    // ── 20 Usuarios (Admin y Recepcionista, 2 inactivos) ─────────────────────
    private static ArrayList<Usuario> datosInicialesUsuarios() {
        ArrayList<Usuario> l = new ArrayList<>();
        l.add(new Usuario("admin",    "Sistema",    "000000000", "admin@garash.com",       "1234", "Admin",         "2024-01-01", true));
        l.add(new Usuario("Ana",      "Garcia",     "600001001", "ana@email.com",           "1234", "Recepcionista", "2024-01-10", true));
        l.add(new Usuario("Carlos",   "Martinez",   "611333444", "carlos@email.com",        "1234", "Recepcionista", "2024-02-15", true));
        l.add(new Usuario("Rosa",     "Campos",     "600201301", "rosa.campos@garash.com",  "1234", "Recepcionista", "2024-03-01", true));
        l.add(new Usuario("Daniel",   "Torres",     "600202302", "daniel@garash.com",       "5678", "Admin",         "2024-03-15", true));
        l.add(new Usuario("Lucia",    "Morales",    "600007007", "lucia.m@email.com",       "1234", "Recepcionista", "2024-04-01", true));
        l.add(new Usuario("Marta",    "Iglesias",   "600015015", "marta.i@email.com",       "1234", "Recepcionista", "2024-04-10", true));
        l.add(new Usuario("Diego",    "Castro",     "600012012", "diego.c@email.com",       "1234", "Recepcionista", "2024-05-01", true));
        l.add(new Usuario("Sara",     "Herrero",    "600011011", "sara.h@email.com",        "1234", "Recepcionista", "2024-05-15", true));
        l.add(new Usuario("Nuria",    "Alonso",     "600013013", "nuria.a@email.com",       "1234", "Recepcionista", "2024-06-01", true));
        l.add(new Usuario("Fernando", "Ortiz",      "600014014", "fernando.o@email.com",    "9999", "Admin",         "2024-06-15", false));
        l.add(new Usuario("Patricia", "Molina",     "600017017", "patricia.m@email.com",    "1234", "Recepcionista", "2024-07-01", true));
        l.add(new Usuario("Beatriz",  "Cruz",       "600019019", "beatriz.c@email.com",     "1234", "Recepcionista", "2024-08-01", true));
        l.add(new Usuario("Hector",   "Vargas",     "600020020", "hector.v@email.com",      "1234", "Recepcionista", "2024-09-01", true));
        l.add(new Usuario("Elena",    "Soler",      "600105205", "elena.soler@garash.com",  "1234", "Recepcionista", "2024-09-15", false));
        l.add(new Usuario("Pablo",    "Jimenez",    "600006006", "pablo.j@email.com",       "1234", "Recepcionista", "2024-10-01", true));
        l.add(new Usuario("Raul",     "Romero",     "600106206", "raul.r@garash.com",       "4321", "Admin",         "2024-10-15", true));
        l.add(new Usuario("Isabel",   "Soler",      "600105205", "isabel.s@garash.com",     "1234", "Recepcionista", "2024-11-01", true));
        l.add(new Usuario("Alberto",  "Ramos",      "600016016", "alberto.r@email.com",     "1234", "Recepcionista", "2025-01-01", true));
        l.add(new Usuario("Roberto",  "Fernandez",  "600004004", "roberto.f@email.com",     "1234", "Recepcionista", "2026-05-01", true));
        return l;
    }
}
