package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.*;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modulos.FuncionesGraficas;

public class VentanaInicialController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private Label labelRol;
    @FXML private MenuItem menuCambiarUsuario;
    @FXML private MenuItem menuSesion;
    @FXML private MenuItem menuAcercaDe;
    @FXML private MenuItem menuIngresosHoy;
    @FXML private MenuItem menuCitasPeluquero;
    @FXML private MenuItem menuResumenMes;
    @FXML private MenuItem menuStockBajo;
    @FXML private MenuItem menuClientesActivos;
    @FXML private MenuItem menuProximasCitas;
    @FXML private Button btnClientes;
    @FXML private Button btnEmpleados;
    @FXML private Button btnCitas;
    @FXML private Button btnProductos;
    @FXML private Button btnServicios;

    private static String usuario;
    private static String tipo;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        labelRol.setText("Rol: " + tipo);
        aplicarRol();
        RecordatorioService.comprobarRecordatorios();
    }

    public static void datosEntrada(String us, String tp) { usuario = us; tipo = tp; }

    private void aplicarRol() {
        if ("Recepcionista".equals(tipo)) {
            deshabilitarBoton(btnEmpleados);
            deshabilitarBoton(btnProductos);
            menuIngresosHoy.setDisable(true);
            menuResumenMes.setDisable(true);
            menuStockBajo.setDisable(true);
        }
    }

    private void deshabilitarBoton(Button btn) { btn.setDisable(true); btn.setOpacity(0.35); }

    @FXML
    private void cambiarUsuario(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource("LoginRegistro.fxml"));
            Scene escena = new Scene(loader.load());
            Stage stage = new Stage();
            stage.setTitle("Garash Studio - Login");
            stage.setResizable(false);
            stage.setScene(escena);
            stage.show();
            ((Stage) btnClientes.getScene().getWindow()).close();
        } catch (IOException e) {
            FuncionesGraficas.warning("Error", "No se pudo abrir el login: " + e.getMessage());
        }
    }

    @FXML private void abrirGestionClientes(ActionEvent event)  throws IOException { GestionClientesController.datosEntrada(usuario);  cargarVentana("GestionClientes",  "Gestion de Clientes"); }
    @FXML private void abrirGestionEmpleados(ActionEvent event) throws IOException { GestionEmpleadosController.datosEntrada(usuario); cargarVentana("GestionEmpleados", "Gestion de Empleados"); }
    @FXML private void abrirGestionCitas(ActionEvent event)     throws IOException { GestionCitasController.datosEntrada(usuario);     cargarVentana("GestionCitas",     "Gestion de Citas"); }
    @FXML private void abrirGestionProductos(ActionEvent event) throws IOException { GestionProductosController.datosEntrada(usuario); cargarVentana("GestionProductos", "Gestion de Productos"); }
    @FXML private void abrirGestionServicios(ActionEvent event) throws IOException { GestionServiciosController.datosEntrada(usuario); cargarVentana("GestionServicios", "Gestion de Servicios"); }
    @FXML private void abrirSalir(ActionEvent event)            throws IOException { SalirController.datosEntrada(usuario);            cargarVentana("Salir",            "Salir"); }

    // ── Estadisticas ──────────────────────────────────────────────────────────

    @FXML
    private void mostrarIngresosHoy(ActionEvent event) { abrirEstadisticas(); }

    @FXML
    private void mostrarCitasPorPeluquero(ActionEvent event) { abrirEstadisticas(); }

    @FXML
    private void mostrarResumenMes(ActionEvent event) {
        java.time.LocalDate hoy = java.time.LocalDate.now();
        String mesNombre = hoy.getMonth().getDisplayName(java.time.format.TextStyle.FULL, new java.util.Locale("es", "ES"));
        String anyo   = String.valueOf(hoy.getYear());
        String prefijo = anyo + "-" + String.format("%02d", hoy.getMonthValue());
        ArrayList<Cita> citas       = GestorFicheros.cargarCitas();
        ArrayList<Servicio> servs   = GestorFicheros.cargarServicios();
        ArrayList<Cliente> clientes = GestorFicheros.cargarClientes();
        int total = 0, cobradas = 0, pendientes = 0, canceladas = 0;
        for (Cita c : citas) {
            if (!c.getFechaHora().startsWith(prefijo)) continue;
            total++;
            if ("Confirmada".equals(c.getEstado()) || "Finalizada".equals(c.getEstado())) cobradas++;
            else if ("Pendiente".equals(c.getEstado()))  pendientes++;
            else if ("Cancelada".equals(c.getEstado())) canceladas++;
        }
        double suma = 0; for (Servicio s : servs) suma += s.getPrecio();
        double avg = servs.isEmpty() ? 0 : suma / servs.size();
        double ingresos = Math.round(cobradas * avg * 100.0) / 100.0;
        long nuevos = 0;
        for (Cliente c : clientes) if (c.getFechaRegistro().startsWith(prefijo)) nuevos++;
        String msg = "Resumen de " + mesNombre + " " + anyo + "\n\n"
            + "Citas totales              : " + total + "\n"
            + "  Confirmadas+Finalizadas  : " + cobradas + "\n"
            + "  Pendientes               : " + pendientes + "\n"
            + "  Canceladas               : " + canceladas + "\n"
            + "────────────────────────────────\n"
            + "Ingresos estimados del mes : " + String.format("%.2f", ingresos) + " EUR\n"
            + "Clientes nuevos este mes   : " + nuevos;
        mostrarInfo("Resumen del Mes", msg);
    }

    private void abrirEstadisticas() {
        try { cargarVentana("Estadisticas", "Estadisticas Garash Studio"); }
        catch (IOException e) { FuncionesGraficas.warning("Error", e.getMessage()); }
    }

    // ── Informes ──────────────────────────────────────────────────────────────

    @FXML
    private void mostrarStockBajo(ActionEvent event) {
        ArrayList<Producto> productos = GestorFicheros.cargarProductos();
        StringBuilder sb = new StringBuilder("Productos con stock bajo\n\n");
        sb.append(String.format("%-30s %8s %8s\n", "Producto", "Stock", "Minimo"));
        for (int i = 0; i < 48; i++) sb.append('─');
        sb.append("\n");
        boolean hay = false;
        for (Producto p : productos) {
            if (p.esStockBajo()) {
                hay = true;
                sb.append(String.format("%-30s %8d %8d\n", p.getNombre(), p.getStockActual(), p.getStockMinimo()));
            }
        }
        if (!hay) sb.append("Todos los productos tienen stock suficiente.");
        mostrarInfo("Stock Bajo", sb.toString());
    }

    @FXML
    private void mostrarClientesActivos(ActionEvent event) {
        ArrayList<Cliente> clientes = GestorFicheros.cargarClientes();
        int activos = 0, inactivos = 0;
        for (Cliente c : clientes) { if (c.isActivo()) activos++; else inactivos++; }
        String msg = "Estado de clientes\n\n"
            + "Total registrados : " + clientes.size() + "\n"
            + "Activos           : " + activos + "\n"
            + "Inactivos         : " + inactivos;
        mostrarInfo("Clientes Activos", msg);
    }

    @FXML
    private void mostrarProximasCitas(ActionEvent event) {
        String hoy    = java.time.LocalDate.now().toString();
        String en7    = java.time.LocalDate.now().plusDays(7).toString();
        ArrayList<Cita> citas       = GestorFicheros.cargarCitas();
        ArrayList<Cliente> clientes = GestorFicheros.cargarClientes();
        ArrayList<Empleado> emps    = GestorFicheros.cargarEmpleados();
        ArrayList<Cita> filtradas   = new ArrayList<>();
        for (Cita c : citas) {
            if ("Cancelada".equals(c.getEstado())) continue;
            String fecha = c.getFechaHora().length() >= 10 ? c.getFechaHora().substring(0, 10) : "";
            if (fecha.compareTo(hoy) >= 0 && fecha.compareTo(en7) <= 0) filtradas.add(c);
        }
        filtradas.sort((a, b) -> a.getFechaHora().compareTo(b.getFechaHora()));
        StringBuilder sb = new StringBuilder("Proximas citas (7 dias)\n\n");
        boolean hay = false;
        int limite = Math.min(10, filtradas.size());
        for (int i = 0; i < limite; i++) {
            hay = true;
            Cita c = filtradas.get(i);
            String nc = "Desconocido", np = "Desconocido";
            for (Cliente cl : clientes) if (cl.getDni() == c.getClienteDni()) { nc = cl.getNombre(); break; }
            for (Empleado e  : emps)    if (e.getDni()  == c.getPeluqueroDni()) { np = e.getNombre();  break; }
            sb.append(">> ").append(c.getFechaHora()).append("\n");
            sb.append("   Cliente   : ").append(nc).append("\n");
            sb.append("   Peluquero : ").append(np).append("\n");
            sb.append("   Estado    : ").append(c.getEstado()).append("\n");
            if (!c.getNotas().isEmpty()) sb.append("   Notas     : ").append(c.getNotas()).append("\n");
            sb.append("\n");
        }
        if (!hay) sb.append("No hay citas en los proximos 7 dias.");
        mostrarInfo("Proximas Citas", sb.toString());
    }

    // ── Sistema ───────────────────────────────────────────────────────────────

    @FXML
    private void mostrarSesion(ActionEvent event) {
        String hoy = java.time.LocalDate.now().toString();
        ArrayList<Cita> citas = GestorFicheros.cargarCitas();
        long citasHoy = 0;
        for (Cita c : citas) if (c.getFechaHora().startsWith(hoy)) citasHoy++;
        String msg = "Usuario   : " + usuario + "\n"
            + "Rol       : " + tipo + "\n"
            + "Fecha     : " + hoy + "\n"
            + "Hora      : " + java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm")) + "\n"
            + "─────────────────────────\n"
            + "Citas hoy : " + citasHoy;
        mostrarInfo("Mi Sesion", msg);
    }

    @FXML
    private void mostrarAcercaDe(ActionEvent event) {
        String msg = "GARASH STUDIO\n"
            + "Sistema de Gestion de Peluqueria\n\n"
            + "Version      : 1.0\n"
            + "Tecnologia   : JavaFX 13 + Ficheros\n"
            + "─────────────────────────────────\n"
            + "Proyecto escolar - DAM1P\n"
            + "Modulo: Programacion";
        mostrarInfo("Acerca de Garash Studio", msg);
    }

    // ── Utilidades ────────────────────────────────────────────────────────────

    private void mostrarInfo(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(titulo);
        alert.setContentText(mensaje);
        alert.getDialogPane().setStyle("-fx-background-color: #1A0030; -fx-font-family: monospace; -fx-font-size: 12px;");
        alert.getDialogPane().lookup(".content.label").setStyle("-fx-text-fill: #E0C8FF; -fx-font-family: monospace;");
        alert.showAndWait();
    }

    public static void cargarVentana(String nombre, String titulo) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(nombre + ".fxml"));
        Scene escena = new Scene(fxmlLoader.load());
        Stage escenario = new Stage();
        escenario.setTitle(titulo);
        escenario.setResizable(false);
        escenario.setScene(escena);
        escenario.initModality(Modality.APPLICATION_MODAL);
        escenario.show();
        escenario.setOnCloseRequest(ev -> {
            ev.consume();
            FuncionesGraficas.warning("Atencion", "Use el boton Salir/Cerrar");
        });
    }
}
