package com.mycompany.garashstudio;

import com.mycompany.garashstudio.clases.Producto;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class GestionProductosController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private TextField campoId;
    @FXML private TextField campoNombre;
    @FXML private TextField campoPrecioCompra;
    @FXML private TextField campoPrecioVenta;
    @FXML private TextField campoStockActual;
    @FXML private TextField campoStockMinimo;
    @FXML private TextField campoProveedor;
    @FXML private TextField campoReponer;
    @FXML private TextField campoRegistro;
    @FXML private TextField campoMensaje;
    @FXML private Button btnSalir;
    @FXML private ListView<String> listaRegistros;

    private static String usuario;
    private ArrayList<Producto> productos = new ArrayList<>();
    private int contReg = 0;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
        cargarDesdeFichero();
        if (!productos.isEmpty()) actualizarCampos();
        listaRegistros.setOnMouseClicked(e -> {
            int idx = listaRegistros.getSelectionModel().getSelectedIndex();
            if (idx >= 0 && idx < productos.size()) { contReg = idx; actualizarCampos(); }
        });
    }

    private void cargarDesdeFichero() {
        productos = GestorFicheros.cargarProductos();
        contReg = 0;
        actualizarLista();
    }

    private void actualizarLista() {
        javafx.collections.ObservableList<String> items = javafx.collections.FXCollections.observableArrayList();
        for (Producto p : productos)
            items.add("ID:" + p.getId() + " | " + p.getNombre() + " | Stock:" + p.getStockActual());
        listaRegistros.setItems(items);
        if (contReg < productos.size()) listaRegistros.getSelectionModel().select(contReg);
    }

    private void actualizarCampos() {
        Producto p = productos.get(contReg);
        campoId.setText(String.valueOf(p.getId()));
        campoNombre.setText(p.getNombre());
        campoPrecioCompra.setText(String.valueOf(p.getPrecioCompra()));
        campoPrecioVenta.setText(String.valueOf(p.getPrecioVenta()));
        campoStockActual.setText(String.valueOf(p.getStockActual()));
        campoStockMinimo.setText(String.valueOf(p.getStockMinimo()));
        campoProveedor.setText(p.getProveedor());
        campoRegistro.setText(contReg + "/" + (productos.size() - 1));
        campoMensaje.setText(p.esStockBajo() ? "Stock bajo: " + p.getNombre() : "");
    }

    private int buscarProducto(int id) {
        for (int i = 0; i < productos.size(); i++)
            if (productos.get(i).getId() == id) return i;
        return -1;
    }

    @FXML
    private void darDeAlta(ActionEvent event) {
        if (campoNombre.getText().isEmpty()) { campoMensaje.setText("El nombre del producto es obligatorio"); return; }
        try {
            double precioCompra = campoPrecioCompra.getText().isEmpty() ? 0.0 : Double.parseDouble(campoPrecioCompra.getText());
            double precioVenta  = campoPrecioVenta.getText().isEmpty()  ? 0.0 : Double.parseDouble(campoPrecioVenta.getText());
            int    stock        = campoStockActual.getText().isEmpty()  ? 0   : Integer.parseInt(campoStockActual.getText());
            int    stockMin     = campoStockMinimo.getText().isEmpty()  ? 0   : Integer.parseInt(campoStockMinimo.getText());
            int nuevoId = GestorFicheros.nextIdProducto();
            productos.add(new Producto(nuevoId, campoNombre.getText(), precioCompra, precioVenta, stock, stockMin, campoProveedor.getText()));
            GestorFicheros.guardarProductos(productos);
            cargarDesdeFichero();
            contReg = productos.size() - 1;
            actualizarCampos();
            campoMensaje.setText("Producto dado de alta: ID " + nuevoId);
        } catch (NumberFormatException e) {
            campoMensaje.setText("Precios y stock deben ser numericos");
        }
    }

    @FXML
    private void darDeBaja(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID del producto"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarProducto(id);
            if (idx == -1) { campoMensaje.setText("No existe producto con ID: " + id); return; }
            productos.remove(idx);
            GestorFicheros.guardarProductos(productos);
            campoMensaje.setText("Producto ID " + id + " eliminado");
            cargarDesdeFichero();
            if (!productos.isEmpty()) actualizarCampos(); else limpiarCampos(event);
        } catch (NumberFormatException e) {
            campoMensaje.setText("El ID debe ser un numero entero");
        }
    }

    @FXML
    private void modificarDatos(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Introduce el ID del producto"); return; }
        try {
            int id = Integer.parseInt(campoId.getText());
            int idx = buscarProducto(id);
            if (idx == -1) { campoMensaje.setText("No existe producto con ID: " + id); return; }
            Producto p = productos.get(idx);
            p.setNombre(campoNombre.getText());
            p.setPrecioCompra(campoPrecioCompra.getText().isEmpty() ? 0.0 : Double.parseDouble(campoPrecioCompra.getText()));
            p.setPrecioVenta(campoPrecioVenta.getText().isEmpty()   ? 0.0 : Double.parseDouble(campoPrecioVenta.getText()));
            p.setStockActual(campoStockActual.getText().isEmpty()   ? 0   : Integer.parseInt(campoStockActual.getText()));
            p.setStockMinimo(campoStockMinimo.getText().isEmpty()   ? 0   : Integer.parseInt(campoStockMinimo.getText()));
            p.setProveedor(campoProveedor.getText());
            GestorFicheros.guardarProductos(productos);
            cargarDesdeFichero();
            contReg = buscarProducto(id);
            actualizarCampos();
            campoMensaje.setText("Producto ID " + id + " modificado");
        } catch (NumberFormatException e) {
            campoMensaje.setText("Precios y stock deben ser numericos");
        }
    }

    @FXML private void irAprimero(ActionEvent event)   { if (!productos.isEmpty()) { contReg = 0; actualizarCampos(); } }
    @FXML private void irAanterior(ActionEvent event)  { if (!productos.isEmpty()) { contReg = (contReg == 0) ? productos.size()-1 : contReg-1; actualizarCampos(); } }
    @FXML private void irAsiguiente(ActionEvent event) { if (!productos.isEmpty()) { contReg = (contReg < productos.size()-1) ? contReg+1 : 0; actualizarCampos(); } }
    @FXML private void irAultimo(ActionEvent event)    { if (!productos.isEmpty()) { contReg = productos.size()-1; actualizarCampos(); } }

    @FXML
    private void reponerStock(ActionEvent event) {
        if (campoId.getText().isEmpty()) { campoMensaje.setText("Navega hasta el producto primero"); return; }
        if (campoReponer.getText().isEmpty()) { campoMensaje.setText("Introduce las unidades a sumar"); return; }
        try {
            int id       = Integer.parseInt(campoId.getText());
            int cantidad = Integer.parseInt(campoReponer.getText());
            if (cantidad <= 0) { campoMensaje.setText("La cantidad debe ser mayor que 0"); return; }
            int idx = buscarProducto(id);
            if (idx == -1) { campoMensaje.setText("No existe producto con ID: " + id); return; }
            productos.get(idx).aumentarStock(cantidad);
            GestorFicheros.guardarProductos(productos);
            cargarDesdeFichero();
            contReg = buscarProducto(id);
            actualizarCampos();
            campoReponer.setText("");
            campoMensaje.setText("Stock repuesto: +" + cantidad + " unidades. Nuevo stock: " + productos.get(contReg).getStockActual());
        } catch (NumberFormatException e) {
            campoMensaje.setText("La cantidad debe ser un numero entero");
        }
    }

    @FXML
    private void limpiarCampos(ActionEvent event) {
        campoId.setText(""); campoNombre.setText(""); campoPrecioCompra.setText("");
        campoPrecioVenta.setText(""); campoStockActual.setText(""); campoStockMinimo.setText("");
        campoProveedor.setText(""); campoRegistro.setText(""); campoMensaje.setText("");
    }

    @FXML
    private void salir(ActionEvent event) { ((Stage) btnSalir.getScene().getWindow()).close(); }

    public static void datosEntrada(String us) { usuario = us; }
}
