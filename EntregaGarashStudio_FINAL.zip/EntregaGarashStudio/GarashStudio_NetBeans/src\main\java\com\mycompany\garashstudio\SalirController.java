package com.mycompany.garashstudio;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class SalirController implements Initializable {

    @FXML private Label labelUsuario;
    @FXML private Button btnSi;
    @FXML private Button btnNo;

    private static String usuario;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        labelUsuario.setText(usuario);
    }

    @FXML
    private void confirmarSalida(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void cancelarSalida(ActionEvent event) {
        Stage ventana = (Stage) btnNo.getScene().getWindow();
        ventana.close();
    }

    public static void datosEntrada(String us) {
        usuario = us;
    }
}
