package com.mycompany.garashstudio.clases;

import java.io.Serializable;

public class Servicio implements Serializable {

    private int id;
    private String nombre;
    private double precio;
    private int duracionMin;
    private String descripcion;
    private String categoria;

    public Servicio(int id, String nombre, double precio, int duracionMin,
                    String descripcion, String categoria) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.duracionMin = duracionMin;
        this.descripcion = descripcion;
        this.categoria = categoria;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getDuracionMin() { return duracionMin; }
    public void setDuracionMin(int duracionMin) { this.duracionMin = duracionMin; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    @Override
    public String toString() {
        return id + " - " + nombre + " (" + categoria + ")";
    }
}
